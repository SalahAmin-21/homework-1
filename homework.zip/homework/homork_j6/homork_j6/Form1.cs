﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.Speech.Synthesis;

namespace homork_j6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

          SpeechSynthesizer synth  = new SpeechSynthesizer();



        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char c = char.ToUpper(e.KeyChar);

                if(c >= 'A' && c <= 'Z')
                { 
                    synth.SpeakAsync(c.ToString());
                
                }
        }
    }
}
