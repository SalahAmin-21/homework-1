﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace homork_j8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool x = false;
            Point s;

        private void button1_MouseDown(object sender, MouseEventArgs e)
        {
            x = true;
            s = e.Location;
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            if (x)
            {

                button1.Left += e.X - s.X;
                button1.Top += e.Y - s.Y;
            
            }
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {

            x = false;

        }
    }
}
